"""VLESS-over-WebSocket relay with per-user accounting, limits and abuse signals."""
import asyncio, socket, time, uuid as _uuid, struct
from collections import defaultdict
import db

active = defaultdict(int)          # uid -> live connections
ips = defaultdict(dict)            # uid -> {ip: last_seen}
_pending = defaultdict(int)        # uid -> bytes not yet flushed
cut = set()                        # users whose live sockets must be dropped
IP_WINDOW = 15 * 60

class VlessError(Exception): pass

def parse_header(data: bytes):
    """Parse a VLESS request header -> (uuid, command, host, port, payload)."""
    if len(data) < 24 or data[0] != 0: raise VlessError("bad version")
    uid = str(_uuid.UUID(bytes=data[1:17]))
    i = 17 + 1 + data[17]                       # skip addons
    cmd = data[i]; port = struct.unpack("!H", data[i + 1:i + 3])[0]; atype = data[i + 3]; i += 4
    if atype == 1: host = socket.inet_ntoa(data[i:i + 4]); i += 4
    elif atype == 2: n = data[i]; host = data[i + 1:i + 1 + n].decode(); i += 1 + n
    elif atype == 3: host = socket.inet_ntop(socket.AF_INET6, data[i:i + 16]); i += 16
    else: raise VlessError("bad address type")
    return uid, cmd, host, port, data[i:]

def _client_ips(uid):
    now = time.time()
    ips[uid] = {ip: t for ip, t in ips[uid].items() if now - t < IP_WINDOW}
    return ips[uid]

async def _open(host, port):
    try: return await asyncio.wait_for(asyncio.open_connection(host, port, family=socket.AF_INET), 8)  # IPv4 first
    except Exception: return await asyncio.wait_for(asyncio.open_connection(host, port), 8)

async def handle(path_uid, client_ip, recv, send, close):
    """recv/send/close are the websocket's async byte primitives."""
    first = await asyncio.wait_for(recv(), 10)
    try: uid, cmd, host, port, payload = parse_header(first)
    except Exception: return await close()
    u = db.get_user(uid)
    ok, why = db.user_state(u)
    if uid != path_uid or not ok:
        if u and not ok: db.log_event(uid, "blocked", why)
        return await close()
    if cmd != 1: return await close()           # TCP only (UDP not supported on Railway)

    seen = _client_ips(uid); seen[client_ip] = time.time()
    if u["max_conn"] and active[uid] >= u["max_conn"]:
        db.log_event(uid, "conn_limit", f"{active[uid]} live connections"); return await close()
    if u["max_ips"] and len(seen) > u["max_ips"]:
        db.log_event(uid, "ip_limit", f"{len(seen)} distinct IPs in 15 min"); seen.pop(client_ip, None); return await close()

    cut.discard(uid)
    active[uid] += 1
    writer = None
    try:
        reader, writer = await _open(host, port)
        if payload: writer.write(payload); await writer.drain()
        await send(b"\x00\x00")                # VLESS response header

        async def up():
            while True:
                data = await recv()
                if not data or uid in cut: break
                _pending[uid] += len(data); writer.write(data); await writer.drain()
        async def down():
            while True:
                data = await reader.read(32768)
                if not data or uid in cut: break
                _pending[uid] += len(data); await send(data)
        tasks = [asyncio.create_task(up()), asyncio.create_task(down())]
        await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for t in tasks: t.cancel()
    except Exception:
        pass
    finally:
        active[uid] -= 1
        if writer:
            try: writer.close()
            except Exception: pass
        flush()
        try: await close()
        except Exception: pass

def flush():
    for uid in list(_pending):
        n = _pending.pop(uid, 0)
        if n: db.add_usage(uid, n)
        if not db.user_state(db.get_user(uid))[0]: cut.add(uid)

async def flusher():
    """Persist counters and cut users who hit quota/expiry (live sockets end on next check)."""
    while True:
        await asyncio.sleep(5); flush()
