"""Telegram bot: customer self-service + AI support + card-to-card sales + admin commands."""
import os, json, asyncio, time
import httpx
import db, ai, abuse

def _token(): return os.environ.get("TELEGRAM_BOT_TOKEN") or db.get_setting("tg_token")
def _admins():
    raw = os.environ.get("TELEGRAM_ADMIN_IDS") or db.get_setting("tg_admins")
    return {int(x) for x in raw.replace(" ", "").split(",") if x.strip().isdigit()}

async def api(method, **params):
    async with httpx.AsyncClient(timeout=40) as c:
        r = await c.post(f"https://api.telegram.org/bot{_token()}/{method}", json=params)
    return r.json()

async def say(chat, text, **kw): return await api("sendMessage", chat_id=chat, text=text, **kw)
def gb(n): return f"{n / db.GB:.2f}"

def status_text(u):
    ok, why = db.user_state(u)
    exp = time.strftime("%Y-%m-%d", time.localtime(u["expire_at"])) if u["expire_at"] else "نامحدود"
    quota = gb(u["quota_bytes"]) + " GB" if u["quota_bytes"] else "نامحدود"
    label = {"active": "✅ فعال", "expired": "⛔ منقضی", "quota": "⛔ حجم تمام شده", "disabled": "⛔ غیرفعال"}.get(why, why)
    return f"{label}\nمصرف: {gb(u['used_bytes'])} GB از {quota}\nانقضا: {exp}\n\nلینک اشتراک:\n{db.sub_url(u['id'])}"

def plans():
    try: return json.loads(db.get_setting("plans", "[]"))
    except Exception: return []

async def handle_message(m):
    chat, uid_tg, text = m["chat"]["id"], m["from"]["id"], (m.get("text") or "").strip()
    is_admin = uid_tg in _admins()
    user = db.user_by_tg(uid_tg)

    if m.get("photo") and db.get_setting(f"awaiting:{uid_tg}"):        # payment receipt
        pid = db.get_setting(f"awaiting:{uid_tg}"); db.set_setting(f"awaiting:{uid_tg}", "")
        plan = next((p for p in plans() if p["id"] == pid), None)
        if not plan: return
        oid = int(db.get_setting("order_seq", "0")) + 1; db.set_setting("order_seq", oid)
        db.set_setting(f"order:{oid}", json.dumps({"tg": uid_tg, "plan": pid, "name": m["from"].get("username") or m["from"].get("first_name", "user")}))
        for a in _admins():
            await api("copyMessage", chat_id=a, from_chat_id=chat, message_id=m["message_id"],
                      caption=f"سفارش #{oid} — {plan['title']} — {plan['price']}\nاز: {m['from'].get('first_name','')} ({uid_tg})",
                      reply_markup={"inline_keyboard": [[{"text": "✅ تأیید", "callback_data": f"ok:{oid}"}, {"text": "❌ رد", "callback_data": f"no:{oid}"}]]})
        return await say(chat, "رسید دریافت شد. بعد از تأیید ادمین، اشتراک برات ارسال می‌شه.")

    if text.startswith("/start"):
        return await say(chat, "سلام 👋\n/usage مصرف و لینک اشتراک\n/link UUID اتصال اشتراک قبلی\n/buy خرید یا تمدید\nهر سؤالی داری همین‌جا بنویس.")
    if text.startswith("/link"):
        parts = text.split()
        u = db.get_user(parts[1]) if len(parts) > 1 else None
        if not u: return await say(chat, "شناسه‌ی اشتراک معتبر نیست.")
        db.update_user(u["id"], tg_id=uid_tg); return await say(chat, "اشتراک به حساب تلگرامت وصل شد ✅")
    if text.startswith("/usage"):
        return await say(chat, status_text(user) if user else "اشتراکی وصل نیست. با /link UUID وصلش کن یا /buy بزن.")
    if text.startswith("/buy"):
        ps = plans()
        if not ps: return await say(chat, "فعلاً پلنی تعریف نشده.")
        return await say(chat, "پلن رو انتخاب کن:", reply_markup={"inline_keyboard": [[{"text": f"{p['title']} — {p['price']}", "callback_data": f"buy:{p['id']}"}] for p in ps]})

    if is_admin and text.startswith("/users"):
        us = db.list_users()[:20]
        return await say(chat, "\n".join(f"{u['name']} — {gb(u['used_bytes'])}GB — {db.user_state(u)[1]}\n{u['id']}" for u in us) or "کاربری نیست")
    if is_admin and text.startswith("/new"):
        p = text.split()                                             # /new name gb days
        if len(p) < 2: return await say(chat, "فرمت: /new نام حجم_GB روز")
        u = db.create_user(p[1], float(p[2]) if len(p) > 2 else 0, int(p[3]) if len(p) > 3 else 0)
        return await say(chat, status_text(u))
    if is_admin and text.startswith("/scan"):
        f = abuse.scan()
        return await say(chat, (await ai.triage(f)) if ai.enabled() and f else ("\n".join(f"{x['name']}: {x['flags'][0]['detail']}" for x in f) or "مورد مشکوکی نیست"))

    if text and not text.startswith("/") and ai.enabled():
        try: return await say(chat, await ai.support_reply(user, text))
        except Exception: return await say(chat, "الان نمی‌تونم جواب بدم؛ چند دقیقه دیگه امتحان کن.")

async def handle_callback(cq):
    data, frm, chat = cq["data"], cq["from"]["id"], cq["message"]["chat"]["id"]
    await api("answerCallbackQuery", callback_query_id=cq["id"])
    if data.startswith("buy:"):
        p = next((x for x in plans() if x["id"] == data[4:]), None)
        if not p: return
        db.set_setting(f"awaiting:{frm}", p["id"])
        return await say(chat, f"{p['title']} — {p['price']}\n\n{db.get_setting('card_info', 'اطلاعات پرداخت تنظیم نشده')}\n\nبعد از پرداخت، عکس رسید رو همین‌جا بفرست.")
    if frm not in _admins(): return
    act, oid = data.split(":")
    raw = db.get_setting(f"order:{oid}")
    if not raw: return await say(chat, "این سفارش قبلاً بررسی شده.")
    o = json.loads(raw); db.set_setting(f"order:{oid}", "")
    if act == "no": return await say(o["tg"], "پرداختت تأیید نشد. اگه اشتباهی شده به پشتیبانی پیام بده.")
    p = next(x for x in plans() if x["id"] == o["plan"])
    u = db.user_by_tg(o["tg"])
    if u: db.update_user(u["id"], quota_bytes=int(p["gb"] * db.GB), used_bytes=0); u = db.extend_days(u["id"], p["days"])
    else: u = db.create_user(o["name"], p["gb"], p["days"], tg_id=o["tg"])
    await say(o["tg"], "✅ پرداخت تأیید شد.\n\n" + status_text(u))
    await say(chat, f"سفارش #{oid} تأیید شد.")

async def run():
    offset = 0
    while True:
        if not _token(): await asyncio.sleep(15); continue
        try:
            res = await api("getUpdates", offset=offset, timeout=25)
            for upd in res.get("result", []):
                offset = upd["update_id"] + 1
                try:
                    if "message" in upd: await handle_message(upd["message"])
                    elif "callback_query" in upd: await handle_callback(upd["callback_query"])
                except Exception as e: print("bot error:", e)
        except Exception: await asyncio.sleep(5)
