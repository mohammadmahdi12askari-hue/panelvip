"""Rule-based abuse signals. The AI layer (ai.py) explains and prioritises them."""
import time, statistics
import db, relay

def scan():
    findings = []
    now = time.time()
    for u in db.list_users():
        if not u["enabled"]: continue
        uid, flags = u["id"], []
        n_ips = len(relay._client_ips(uid))
        limit = u["max_ips"] or 5
        if n_ips > limit:
            flags.append({"type": "ip_spread", "detail": f"{n_ips} distinct IPs in 15 min (limit {limit})", "score": min(100, 40 + 15 * (n_ips - limit))})
        hist = db.hourly_history(uid, 168)
        if len(hist) >= 6:
            last = hist[-1]; base = statistics.median(hist[:-1]) or 1
            if last > 200 * 1024**2 and last > 6 * base:
                flags.append({"type": "traffic_spike", "detail": f"{last // 1024**2} MB last hour vs median {int(base) // 1024**2} MB", "score": 55})
        if u["quota_bytes"] and u["expire_at"]:
            total = max(u["expire_at"] - u["created_at"], 1)
            time_used = (now - u["created_at"]) / total
            quota_used = u["used_bytes"] / u["quota_bytes"]
            if quota_used > 0.8 and time_used < 0.4:
                flags.append({"type": "fast_burn", "detail": f"{quota_used:.0%} of quota used after {time_used:.0%} of the period", "score": 35})
        if relay.active[uid] > (u["max_conn"] or 200):
            flags.append({"type": "many_connections", "detail": f"{relay.active[uid]} live connections", "score": 45})
        if flags:
            findings.append({"uid": uid, "name": u["name"], "score": max(f["score"] for f in flags), "flags": flags})
            for f in flags: db.log_event(uid, f["type"], f["detail"])
    return sorted(findings, key=lambda f: -f["score"])
