# پنل اشتراک هوشمند

پنل مدیریت اشتراک (VLESS + WebSocket) با دستیار هوشمند، ربات تلگرام و تشخیص سوءاستفاده. آماده‌ی دیپلوی روی Railway.

## دیپلوی روی Railway (۵ قدم)
1. ریپو را در GitHub بساز و فایل‌های این پوشه را آپلود کن.
2. Railway ← **New Project** ← **Deploy from GitHub repo** ← ریپو را انتخاب کن. (چون `Dockerfile` و `railway.toml` هست، خودش بیلد می‌کند.)
3. روی سرویس: **Settings ← Networking ← Generate Domain**.
4. روی سرویس: راست‌کلیک (یا Ctrl+K) ← **Add Volume**. مسیر mount مهم نیست؛ پنل خودش پیدا می‌کند.
5. تب **Deployments ← View logs** را باز کن. آدرس کامل ورود چاپ می‌شود:
   `PANEL LOGIN: https://دامنه/p-xxxx/login`
   آن را باز کن و رمز مدیر را بساز.

اگر در لاگ هشدار `no Volume attached` دیدی، مرحله‌ی ۴ را انجام بده و Redeploy کن. برای اطمینان: `https://دامنه/health` باید `"persistent": true` نشان بدهد.

## متغیرهای محیطی (همه اختیاری، از داخل پنل هم قابل تنظیم‌اند)
| متغیر | کاربرد |
|---|---|
| `PANEL_PATH` | مسیر مخفی پنل (پیش‌فرض: تصادفی) |
| `ADMIN_PASSWORD` | رمز ثابت مدیر |
| `ANTHROPIC_API_KEY` | فعال‌سازی هوش مصنوعی |
| `AI_MODEL` | مدل (پیش‌فرض `claude-sonnet-5`) |
| `TELEGRAM_BOT_TOKEN` / `TELEGRAM_ADMIN_IDS` | ربات تلگرام |
| `PUBLIC_HOST` | دامنه داخل لینک‌ها (پیش‌فرض دامنه Railway) |

## امکانات
- ساخت کاربر با حجم، انقضا، محدودیت IP و اتصال؛ قطع خودکار بعد از اتمام حجم/انقضا
- صفحه‌ی اشتراک کاربر (مصرف، QR، کپی لینک) و خروجی سازگار با v2rayNG / Hiddify / Streisand
- **دستیار مدیر**: مدیریت با زبان طبیعی (ساخت، تمدید، غیرفعال‌سازی، بررسی)
- **تشخیص سوءاستفاده**: اشتراک‌گذاری اکانت (IP زیاد)، جهش ترافیک، مصرف سریع؛ با تحلیل و پیشنهاد هوش مصنوعی
- **ربات تلگرام**: `/usage`، `/link`، پشتیبانی هوشمند، فروش کارت‌به‌کارت با تأیید ادمین (`/buy`)؛ دستورات ادمین `/users` `/new` `/scan`

## محدودیت‌ها
پروتکل‌ها: VLESS روی WebSocket و XHTTP (حالت‌های packet-up و stream-up)، فقط TCP. UDP، WireGuard و MTProto پشتیبانی نمی‌شوند.
حالت XHTTP با کلاینت واقعی Xray تست نشده؛ اگر اتصال برقرار نشد، حالت را در کلاینت روی packet-up بگذار و لاگ را بفرست.

## اجرا روی VPS (داکر)
`docker build -t panel . && docker run -d --restart=always -p 8000:8000 -v panel-data:/data panel`
سپس پشت یک reverse proxy با TLS (مثل Caddy) قرار بده.
