"""Claude-powered features: admin assistant (tool use), customer support, abuse triage."""
import os, json, time
import httpx
import db, abuse

API = "https://api.anthropic.com/v1/messages"
def _key(): return os.environ.get("ANTHROPIC_API_KEY") or db.get_setting("anthropic_key")
def _model(): return os.environ.get("AI_MODEL") or db.get_setting("ai_model") or "claude-sonnet-5"
def enabled(): return bool(_key())

async def _call(system, messages, tools=None, max_tokens=1200):
    body = {"model": _model(), "max_tokens": max_tokens, "system": system, "messages": messages}
    if tools: body["tools"] = tools
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.post(API, json=body, headers={"x-api-key": _key(), "anthropic-version": "2023-06-01", "content-type": "application/json"})
    if r.status_code != 200: raise RuntimeError(f"AI error {r.status_code}: {r.text[:200]}")
    return r.json()

def _text(resp): return "".join(b.get("text", "") for b in resp["content"] if b["type"] == "text").strip()
def _brief(u):
    return {"id": u["id"], "name": u["name"], "used_gb": round(u["used_bytes"] / db.GB, 2), "quota_gb": round(u["quota_bytes"] / db.GB, 2),
            "expires": time.strftime("%Y-%m-%d", time.localtime(u["expire_at"])) if u["expire_at"] else "never",
            "enabled": bool(u["enabled"]), "state": db.user_state(u)[1]}

# ---- admin assistant -------------------------------------------------------
TOOLS = [
 {"name": "list_users", "description": "List users, optionally filtered by name/id text.", "input_schema": {"type": "object", "properties": {"search": {"type": "string"}}}},
 {"name": "create_user", "description": "Create a subscription user. quota_gb=0 or days=0 means unlimited.", "input_schema": {"type": "object", "properties": {"name": {"type": "string"}, "quota_gb": {"type": "number"}, "days": {"type": "integer"}, "max_ips": {"type": "integer"}}, "required": ["name"]}},
 {"name": "update_user", "description": "Change a user: enable/disable, quota_gb, add_days, rename, reset usage.", "input_schema": {"type": "object", "properties": {"id": {"type": "string"}, "enabled": {"type": "boolean"}, "quota_gb": {"type": "number"}, "add_days": {"type": "integer"}, "name": {"type": "string"}, "reset_usage": {"type": "boolean"}}, "required": ["id"]}},
 {"name": "delete_user", "description": "Permanently delete a user. Only after the admin clearly asked for it.", "input_schema": {"type": "object", "properties": {"id": {"type": "string"}}, "required": ["id"]}},
 {"name": "scan_abuse", "description": "Run abuse detection now and return findings.", "input_schema": {"type": "object", "properties": {}}},
 {"name": "overview", "description": "Totals: users, active, traffic in last 24h.", "input_schema": {"type": "object", "properties": {}}},
]

def run_tool(name, a):
    if name == "list_users":
        us = db.find_users(a["search"]) if a.get("search") else db.list_users()[:30]
        return [_brief(u) for u in us]
    if name == "create_user":
        u = db.create_user(a["name"], a.get("quota_gb", 0), a.get("days", 0), max_ips=a.get("max_ips", 0)); return _brief(u)
    if name == "update_user":
        uid = a["id"]
        if not db.get_user(uid): return {"error": "user not found"}
        kw = {k: a[k] for k in ("enabled", "quota_gb", "name") if k in a}
        if "enabled" in kw: kw["enabled"] = int(kw["enabled"])
        if a.get("reset_usage"): kw["used_bytes"] = 0
        u = db.update_user(uid, **kw)
        if a.get("add_days"): u = db.extend_days(uid, a["add_days"])
        return _brief(u)
    if name == "delete_user":
        db.delete_user(a["id"]); return {"deleted": a["id"]}
    if name == "scan_abuse": return abuse.scan()[:15]
    if name == "overview":
        us = db.list_users()
        return {"users": len(us), "active": sum(db.user_state(u)[0] for u in us),
                "traffic_24h_gb": round(sum(p["bytes"] for p in db.usage_series(None, 24)) / db.GB, 2)}
    return {"error": "unknown tool"}

ADMIN_SYS = ("You are the assistant inside a VPN subscription admin panel. The admin writes in Persian (or English); answer in the same language, briefly. "
             "Use the tools to act; never invent user ids. For deletions, confirm first unless the request is explicit. After acting, state what changed in one or two lines.")

async def admin_chat(history):
    msgs = list(history)
    for _ in range(6):
        resp = await _call(ADMIN_SYS, msgs, TOOLS)
        if resp["stop_reason"] != "tool_use": return _text(resp) or "انجام شد."
        msgs.append({"role": "assistant", "content": resp["content"]})
        results = []
        for b in resp["content"]:
            if b["type"] == "tool_use":
                try: out = run_tool(b["name"], b["input"])
                except Exception as e: out = {"error": str(e)}
                results.append({"type": "tool_result", "tool_use_id": b["id"], "content": json.dumps(out, ensure_ascii=False)})
        msgs.append({"role": "user", "content": results})
    return "درخواست پیچیده بود؛ لطفاً ساده‌تر بپرس."

# ---- abuse triage ----------------------------------------------------------
async def triage(findings):
    if not findings: return "مورد مشکوکی پیدا نشد."
    sys = ("You review abuse signals for a VPN panel. For each user say in Persian, one line each: likely cause (account sharing, "
           "automated scraping, normal heavy use...) and a recommended action (ignore / warn / limit / disable). Be cautious: signals are heuristics, not proof.")
    resp = await _call(sys, [{"role": "user", "content": json.dumps(findings[:10], ensure_ascii=False)}], max_tokens=900)
    return _text(resp)

# ---- customer support (Telegram) ------------------------------------------
async def support_reply(user, question):
    ctx = json.dumps(_brief(user), ensure_ascii=False) if user else "no account linked"
    sys = ("You are a friendly support agent for a VPN service. Reply in Persian, short and clear (max 5 lines). "
           "You may only use the account data provided. You cannot change accounts, refund, or promise anything; "
           "for renewals or payment tell the user to press /buy or contact the admin. Common fixes: update the subscription link in the app, "
           "check device date/time, switch between WS and XHTTP configs, try mobile data vs Wi-Fi. Account data: " + ctx)
    return _text(await _call(sys, [{"role": "user", "content": question[:1000]}], max_tokens=500))
