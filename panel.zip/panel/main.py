import os, time, hmac, hashlib, base64, secrets, asyncio, urllib.parse
from contextlib import asynccontextmanager
from fastapi import FastAPI, APIRouter, Request, WebSocket, Depends, HTTPException
from fastapi.responses import StreamingResponse, HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse, Response
import db, relay, abuse, ai, bot, xhttp

VERSION = "1.0.0"
HERE = os.path.dirname(__file__)
def page(name): return open(os.path.join(HERE, "static", name), encoding="utf-8").read()

# ---- panel path & auth -------------------------------------------------------
def panel_path():
    p = (os.environ.get("PANEL_PATH") or db.get_setting("panel_path") or "").strip("/")
    if not p:
        p = "p-" + secrets.token_urlsafe(9).replace("_", "x").replace("-", "y"); db.set_setting("panel_path", p)
    return p
P = panel_path()

def _secret():
    s = db.get_setting("secret")
    if not s: s = secrets.token_hex(32); db.set_setting("secret", s)
    return s.encode()
def _hash(pw, salt): return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000).hex()
def set_password(pw):
    salt = secrets.token_bytes(16); db.set_setting("pw", salt.hex() + ":" + _hash(pw, salt))
def check_password(pw):
    env = os.environ.get("ADMIN_PASSWORD")
    if env: return hmac.compare_digest(pw, env)
    stored = db.get_setting("pw")
    if not stored: return False
    salt, h = stored.split(":"); return hmac.compare_digest(_hash(pw, bytes.fromhex(salt)), h)
def needs_setup(): return not os.environ.get("ADMIN_PASSWORD") and not db.get_setting("pw")

def make_token():
    exp = str(int(time.time()) + 7 * 86400)
    return exp + "." + hmac.new(_secret(), exp.encode(), hashlib.sha256).hexdigest()
def valid_token(t):
    try:
        exp, sig = t.split(".")
        return int(exp) > time.time() and hmac.compare_digest(sig, hmac.new(_secret(), exp.encode(), hashlib.sha256).hexdigest())
    except Exception: return False
def require_admin(req: Request):
    if not valid_token(req.cookies.get("sess", "")): raise HTTPException(401)

_attempts = {}
def _limited(ip):
    a = [t for t in _attempts.get(ip, []) if time.time() - t < 600]; _attempts[ip] = a; return len(a) >= 8
def _ip(req): return (req.headers.get("x-forwarded-for", "").split(",")[0].strip() or (req.client.host if req.client else "?"))

# ---- app ---------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app):
    async def scanner():
        while True:
            await asyncio.sleep(600)
            try: abuse.scan()
            except Exception as e: print("scan error", e)
    tasks = [asyncio.create_task(relay.flusher()), asyncio.create_task(bot.run()), asyncio.create_task(scanner()), asyncio.create_task(xhttp.sweeper())]
    dom = os.environ.get("RAILWAY_PUBLIC_DOMAIN") or db.get_setting("public_host") or "YOUR-DOMAIN"
    print("=" * 60); print(f"PANEL LOGIN: https://{dom}/{P}/login")
    if not db.HAS_VOLUME: print("WARNING: no Volume attached - users and settings will be LOST on redeploy. Add a Volume in Railway.")
    print("=" * 60)
    yield
    relay.flush()
    for t in tasks: t.cancel()

app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
admin = APIRouter(prefix=f"/{P}")

@admin.get("/login", response_class=HTMLResponse)
def login_page(): return page("login.html").replace("__P__", P).replace("__SETUP__", "1" if needs_setup() else "0")

@admin.post("/login")
async def login(req: Request):
    ip = _ip(req)
    if _limited(ip): raise HTTPException(429, "too many attempts")
    body = await req.json(); pw = str(body.get("password", ""))
    if needs_setup():
        if len(pw) < 8: raise HTTPException(400, "رمز باید حداقل ۸ کاراکتر باشد")
        set_password(pw)
    elif not check_password(pw):
        _attempts.setdefault(ip, []).append(time.time()); raise HTTPException(401, "رمز اشتباه است")
    r = JSONResponse({"ok": True})
    r.set_cookie("sess", make_token(), httponly=True, secure=True, samesite="strict", max_age=7 * 86400, path="/")
    return r

@admin.get("/", response_class=HTMLResponse)
def dashboard(req: Request):
    if not valid_token(req.cookies.get("sess", "")): return RedirectResponse(f"/{P}/login")
    return page("admin.html").replace("__P__", P)

def user_view(u):
    ok, why = db.user_state(u)
    return {**u, "state": why, "active": ok, "live": relay.active.get(u["id"], 0), "ips": len(relay._client_ips(u["id"])), "sub": db.sub_url(u["id"])}

@admin.get("/api/overview", dependencies=[Depends(require_admin)])
def overview():
    us = db.list_users()
    return {"users": len(us), "active": sum(db.user_state(u)[0] for u in us), "live": sum(relay.active.values()),
            "traffic_total": sum(u["used_bytes"] for u in us), "series": db.usage_series(None, 24),
            "events": db.recent_events(15), "ai": ai.enabled(), "version": VERSION}

@admin.get("/api/users", dependencies=[Depends(require_admin)])
def users(): return [user_view(u) for u in db.list_users()]

@admin.post("/api/users", dependencies=[Depends(require_admin)])
async def create(req: Request):
    b = await req.json()
    if not str(b.get("name", "")).strip(): raise HTTPException(400, "نام لازم است")
    return user_view(db.create_user(b["name"], b.get("quota_gb") or 0, b.get("days") or 0, b.get("max_conn") or 0, b.get("max_ips") or 0, b.get("note", "")))

@admin.patch("/api/users/{uid}", dependencies=[Depends(require_admin)])
async def patch(uid: str, req: Request):
    if not db.get_user(uid): raise HTTPException(404)
    b = await req.json()
    add = b.pop("add_days", 0)
    if b.pop("reset_usage", False): b["used_bytes"] = 0
    u = db.update_user(uid, **b)
    if add: u = db.extend_days(uid, int(add))
    return user_view(u)

@admin.delete("/api/users/{uid}", dependencies=[Depends(require_admin)])
def remove(uid: str): db.delete_user(uid); return {"ok": True}

@admin.post("/api/abuse/scan", dependencies=[Depends(require_admin)])
async def scan():
    f = abuse.scan()
    return {"findings": f, "analysis": (await ai.triage(f)) if ai.enabled() and f else None}

@admin.post("/api/ai/chat", dependencies=[Depends(require_admin)])
async def chat(req: Request):
    if not ai.enabled(): raise HTTPException(400, "کلید ANTHROPIC_API_KEY تنظیم نشده")
    try: return {"reply": await ai.admin_chat((await req.json())["messages"][-20:])}
    except Exception as e: raise HTTPException(502, str(e))

SETTING_KEYS = ["public_host", "tg_token", "tg_admins", "anthropic_key", "ai_model", "card_info", "plans"]
SECRET_KEYS = {"tg_token", "anthropic_key"}
@admin.get("/api/settings", dependencies=[Depends(require_admin)])
def get_settings():
    return {k: ("••••••" if k in SECRET_KEYS and db.get_setting(k) else db.get_setting(k)) for k in SETTING_KEYS}

@admin.post("/api/settings", dependencies=[Depends(require_admin)])
async def save_settings(req: Request):
    for k, v in (await req.json()).items():
        if k in SETTING_KEYS and v != "••••••": db.set_setting(k, v)
    return {"ok": True}

@admin.post("/api/password", dependencies=[Depends(require_admin)])
async def change_pw(req: Request):
    pw = str((await req.json()).get("password", ""))
    if len(pw) < 8: raise HTTPException(400, "حداقل ۸ کاراکتر")
    set_password(pw); return {"ok": True}

app.include_router(admin)

# ---- public: subscription ------------------------------------------------------
def vless_link(u):
    h = db.public_host()
    q = urllib.parse.urlencode({"encryption": "none", "security": "tls", "sni": h, "fp": "chrome", "type": "ws", "host": h, "path": f"/ws/{u['id']}"})
    return f"vless://{u['id']}@{h}:443?{q}#{urllib.parse.quote(u['name'] + ' WS')}"

def xhttp_link(u):
    h = db.public_host()
    q = urllib.parse.urlencode({"encryption": "none", "security": "tls", "sni": h, "fp": "chrome", "type": "xhttp", "host": h,
                                "path": f"/xhttp/{u['id']}", "mode": "packet-up"})
    return f"vless://{u['id']}@{h}:443?{q}#{urllib.parse.quote(u['name'] + ' XHTTP')}"

def all_links(u): return [vless_link(u), xhttp_link(u)]

@app.get("/sub/{uid}")
def sub(uid: str, req: Request):
    u = db.get_user(uid)
    if not u: raise HTTPException(404)
    if "text/html" in req.headers.get("accept", ""): return HTMLResponse(page("sub.html"))
    body = base64.b64encode("\n".join(all_links(u)).encode()).decode() if db.user_state(u)[0] else ""
    return PlainTextResponse(body, headers={
        "subscription-userinfo": f"upload=0; download={u['used_bytes']}; total={u['quota_bytes']}; expire={u['expire_at']}",
        "profile-update-interval": "6", "profile-title": u["name"]})

@app.get("/api/public/usage/{uid}")
def public_usage(uid: str):
    u = db.get_user(uid)
    if not u: raise HTTPException(404)
    ok, why = db.user_state(u)
    return {"name": u["name"], "state": why, "used": u["used_bytes"], "quota": u["quota_bytes"], "expire_at": u["expire_at"],
            "link": vless_link(u), "xhttp": xhttp_link(u), "sub": db.sub_url(uid), "series": db.usage_series(uid, 24 * 7)[::1][-168:]}

@app.get("/sub/{uid}/qr.svg")
def qr(uid: str):
    u = db.get_user(uid)
    if not u: raise HTTPException(404)
    try:
        import segno, io
        buf = io.BytesIO(); segno.make(db.sub_url(uid), error="m").save(buf, kind="svg", scale=6, border=2, dark="#101828"); return Response(buf.getvalue(), media_type="image/svg+xml")
    except ImportError: raise HTTPException(501, "segno not installed")

@app.get("/health")
def health(): return {"ok": True, "version": VERSION, "persistent": db.HAS_VOLUME}

# ---- public: tunnel ------------------------------------------------------------
@app.websocket("/ws/{uid}")
async def tunnel(ws: WebSocket, uid: str):
    await ws.accept()
    async def recv():
        m = await ws.receive()
        if m["type"] == "websocket.disconnect": return b""
        return m.get("bytes") or (m.get("text") or "").encode()
    async def close():
        try: await ws.close()
        except Exception: pass
    ip = ws.headers.get("x-real-ip") or ws.headers.get("x-forwarded-for", "").split(",")[0].strip() or (ws.client.host if ws.client else "?")
    try: await relay.handle(uid, ip, recv, ws.send_bytes, close)
    except Exception: await close()

# ---- public: XHTTP tunnel ------------------------------------------------------
def _cip(req): return req.headers.get("x-real-ip") or _ip(req)
NOBUF = {"Cache-Control": "no-store", "X-Accel-Buffering": "no", "Content-Type": "application/octet-stream"}

@app.get("/xhttp/{uid}/{sid}")
async def xhttp_down(uid: str, sid: str, req: Request):
    if not db.get_user(uid) or len(sid) > 64: raise HTTPException(404)
    s = xhttp.get_session(uid, sid, _cip(req))
    if s.got_get: raise HTTPException(409)
    return StreamingResponse(xhttp.downlink(sid, s), headers=NOBUF)

@app.post("/xhttp/{uid}/{sid}/{seq}")
async def xhttp_packet(uid: str, sid: str, seq: int, req: Request):
    if not db.get_user(uid) or len(sid) > 64: raise HTTPException(404)
    s = xhttp.get_session(uid, sid, _cip(req))
    body = await req.body()
    if len(body) > 4 * 1024 * 1024 or not s.put_packet(seq, body): raise HTTPException(400)
    return Response(status_code=200, headers={"Cache-Control": "no-store"})

@app.post("/xhttp/{uid}/{sid}")
async def xhttp_stream_up(uid: str, sid: str, req: Request):
    if not db.get_user(uid) or len(sid) > 64: raise HTTPException(404)
    s = xhttp.get_session(uid, sid, _cip(req))
    async for chunk in req.stream():
        if s.dead: break
        if chunk: s.put_stream(chunk)
    return Response(status_code=200, headers={"Cache-Control": "no-store"})
