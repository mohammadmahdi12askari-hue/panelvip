"""SQLite storage. Everything lives in DATA_DIR (mount a Railway Volume there)."""
import os, sqlite3, threading, time, uuid as _uuid, json

DATA_DIR = (os.environ.get("DATA_DIR") or os.environ.get("RAILWAY_VOLUME_MOUNT_PATH")
            or ("/data" if os.path.isdir("/data") else "./data"))
HAS_VOLUME = bool(os.environ.get("RAILWAY_VOLUME_MOUNT_PATH")) or os.path.ismount(DATA_DIR)
os.makedirs(DATA_DIR, exist_ok=True)
_lock = threading.RLock()
_conn = sqlite3.connect(os.path.join(DATA_DIR, "panel.db"), check_same_thread=False)
_conn.row_factory = sqlite3.Row
_conn.executescript("""
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(
  id TEXT PRIMARY KEY, name TEXT NOT NULL, quota_bytes INTEGER DEFAULT 0,
  used_bytes INTEGER DEFAULT 0, expire_at INTEGER DEFAULT 0, max_conn INTEGER DEFAULT 0,
  max_ips INTEGER DEFAULT 0, enabled INTEGER DEFAULT 1, note TEXT DEFAULT '',
  tg_id INTEGER DEFAULT 0, created_at INTEGER);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS usage_hourly(uid TEXT, hour INTEGER, bytes INTEGER, PRIMARY KEY(uid,hour));
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, uid TEXT, kind TEXT, detail TEXT);
""")

GB = 1024 ** 3

def _q(sql, args=(), one=False):
    with _lock:
        cur = _conn.execute(sql, args)
        rows = cur.fetchall()
        _conn.commit()
    return (rows[0] if rows else None) if one else rows

# ---- settings -------------------------------------------------------------
def get_setting(k, default=""):
    r = _q("SELECT v FROM settings WHERE k=?", (k,), one=True)
    return r["v"] if r else default

def set_setting(k, v):
    _q("INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))

# ---- users ----------------------------------------------------------------
def _d(r): return dict(r) if r else None

def create_user(name, quota_gb=0, days=0, max_conn=0, max_ips=0, note="", tg_id=0):
    uid = str(_uuid.uuid4())
    exp = int(time.time() + days * 86400) if days else 0
    _q("INSERT INTO users(id,name,quota_bytes,expire_at,max_conn,max_ips,note,tg_id,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
       (uid, name.strip()[:64], int(float(quota_gb) * GB), exp, int(max_conn), int(max_ips), note[:500], int(tg_id), int(time.time())))
    return get_user(uid)

def get_user(uid): return _d(_q("SELECT * FROM users WHERE id=?", (uid,), one=True))
def list_users(): return [dict(r) for r in _q("SELECT * FROM users ORDER BY created_at DESC")]
def find_users(text):
    like = f"%{text}%"
    return [dict(r) for r in _q("SELECT * FROM users WHERE name LIKE ? OR id LIKE ? LIMIT 20", (like, like))]
def user_by_tg(tg_id): return _d(_q("SELECT * FROM users WHERE tg_id=? LIMIT 1", (tg_id,), one=True))

_FIELDS = {"name", "quota_bytes", "expire_at", "max_conn", "max_ips", "enabled", "note", "tg_id", "used_bytes"}
def update_user(uid, **kw):
    if "quota_gb" in kw: kw["quota_bytes"] = int(float(kw.pop("quota_gb")) * GB)
    kw = {k: v for k, v in kw.items() if k in _FIELDS}
    if not kw: return get_user(uid)
    sets = ",".join(f"{k}=?" for k in kw)
    _q(f"UPDATE users SET {sets} WHERE id=?", (*kw.values(), uid))
    return get_user(uid)

def extend_days(uid, days):
    u = get_user(uid)
    base = max(u["expire_at"], int(time.time())) if u["expire_at"] else int(time.time())
    return update_user(uid, expire_at=int(base + days * 86400))

def delete_user(uid):
    _q("DELETE FROM users WHERE id=?", (uid,)); _q("DELETE FROM usage_hourly WHERE uid=?", (uid,))

def user_state(u):
    """Returns (ok, reason)."""
    if not u: return False, "unknown"
    if not u["enabled"]: return False, "disabled"
    if u["expire_at"] and u["expire_at"] < time.time(): return False, "expired"
    if u["quota_bytes"] and u["used_bytes"] >= u["quota_bytes"]: return False, "quota"
    return True, "active"

# ---- usage ----------------------------------------------------------------
def add_usage(uid, nbytes):
    if nbytes <= 0: return
    hour = int(time.time() // 3600)
    _q("UPDATE users SET used_bytes=used_bytes+? WHERE id=?", (nbytes, uid))
    _q("INSERT INTO usage_hourly(uid,hour,bytes) VALUES(?,?,?) ON CONFLICT(uid,hour) DO UPDATE SET bytes=bytes+excluded.bytes",
       (uid, hour, nbytes))

def usage_series(uid=None, hours=24):
    since = int(time.time() // 3600) - hours + 1
    if uid: rows = _q("SELECT hour,bytes FROM usage_hourly WHERE uid=? AND hour>=?", (uid, since))
    else: rows = _q("SELECT hour,SUM(bytes) bytes FROM usage_hourly WHERE hour>=? GROUP BY hour", (since,))
    m = {r["hour"]: r["bytes"] for r in rows}
    return [{"hour": h * 3600, "bytes": m.get(h, 0)} for h in range(since, since + hours)]

def hourly_history(uid, hours=168):
    since = int(time.time() // 3600) - hours
    return [r["bytes"] for r in _q("SELECT bytes FROM usage_hourly WHERE uid=? AND hour>=? ORDER BY hour", (uid, since))]

# ---- events ---------------------------------------------------------------
def log_event(uid, kind, detail=""):
    recent = _q("SELECT id FROM events WHERE uid=? AND kind=? AND ts>? LIMIT 1", (uid, kind, int(time.time()) - 3600), one=True)
    if recent: return  # de-duplicate within an hour
    _q("INSERT INTO events(ts,uid,kind,detail) VALUES(?,?,?,?)", (int(time.time()), uid, kind, detail[:300]))

def recent_events(limit=50):
    return [dict(r) for r in _q("SELECT e.*, u.name FROM events e LEFT JOIN users u ON u.id=e.uid ORDER BY e.id DESC LIMIT ?", (limit,))]

# ---- misc -----------------------------------------------------------------
def public_host():
    return (os.environ.get("PUBLIC_HOST") or get_setting("public_host") or os.environ.get("RAILWAY_PUBLIC_DOMAIN") or "localhost")

def sub_url(uid): return f"https://{public_host()}/sub/{uid}"
