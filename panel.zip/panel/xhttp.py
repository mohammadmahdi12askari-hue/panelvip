"""XHTTP (SplitHTTP) transport: packet-up and stream-up modes, feeding the same VLESS relay as WebSocket."""
import asyncio, time
import relay

SESSIONS = {}                 # sid -> Session
MAX_PENDING = 64              # out-of-order uplink packets we will buffer per session
IDLE_NO_GET = 30              # drop a session if no downlink GET arrives in this many seconds

class Session:
    def __init__(self, uid, ip):
        self.up, self.down = asyncio.Queue(), asyncio.Queue()
        self.pending, self.next, self.born, self.got_get, self.dead = {}, 0, time.time(), False, False
        self.task = asyncio.create_task(relay.handle(uid, ip, self._recv, self._send, self._close))
        self.task.add_done_callback(lambda _: self._close_sync())

    async def _recv(self):
        d = await self.up.get()
        return b"" if d is None else d
    async def _send(self, data): self.down.put_nowait(data)
    async def _close(self): self._close_sync()
    def _close_sync(self):
        if not self.dead: self.dead = True; self.down.put_nowait(None)

    def put_packet(self, seq, data):
        if self.dead or len(self.pending) > MAX_PENDING: return False
        self.pending[seq] = data
        while self.next in self.pending: self.up.put_nowait(self.pending.pop(self.next)); self.next += 1
        return True
    def put_stream(self, data): self.up.put_nowait(data)

    def destroy(self):
        self.up.put_nowait(None); self._close_sync()
        if not self.task.done(): self.task.cancel()

def get_session(uid, sid, ip, create=True):
    s = SESSIONS.get(sid)
    if s is None and create:
        s = SESSIONS[sid] = Session(uid, ip)
    return s

def drop(sid):
    s = SESSIONS.pop(sid, None)
    if s: s.destroy()

async def downlink(sid, s):
    """Async generator for the GET response body."""
    s.got_get = True
    try:
        while True:
            try: data = await asyncio.wait_for(s.down.get(), 120)
            except asyncio.TimeoutError: break
            if data is None: break
            yield data
    finally:
        drop(sid)

async def sweeper():
    while True:
        await asyncio.sleep(10)
        now = time.time()
        for sid, s in list(SESSIONS.items()):
            if (not s.got_get and now - s.born > IDLE_NO_GET) or (s.dead and s.down.empty()): drop(sid)
